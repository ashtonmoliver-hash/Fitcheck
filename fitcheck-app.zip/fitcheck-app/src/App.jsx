import { useState, useRef, useCallback } from "react";

const STYLE_META = {
  "Goth":               { tags:["dark","black","heavy","shadow","velvet","lace","mysterious","edgy","moody"], season:["Fall","Winter"], emoji:"🖤", accent:"#9b59b6", bg:"#1a0a2e" },
  "Cottagecore":        { tags:["floral","natural","garden","linen","soft","earthy","dreamy","prairie","whimsical"], season:["Spring","Summer"], emoji:"🌿", accent:"#6a9e6a", bg:"#f0e6d3" },
  "Streetwear":         { tags:["urban","hype","sneakers","oversized","graphic","cargo","city","fresh","drip"], season:["All"], emoji:"🔥", accent:"#ff6b35", bg:"#1a1a1a" },
  "Y2K":                { tags:["2000s","retro","low-rise","rhinestone","butterfly","nostalgia","flashy","metallic","pop"], season:["Spring","Summer"], emoji:"💿", accent:"#ff66bb", bg:"#ffe0f0" },
  "Boho":               { tags:["flowy","earthy","fringe","woven","festival","free spirit","layered","wanderlust"], season:["Spring","Summer"], emoji:"🌙", accent:"#c9956c", bg:"#5a3a20" },
  "Dark Academia":      { tags:["scholarly","plaid","tweed","intellectual","moody","library","autumnal","brooding"], season:["Fall","Winter"], emoji:"📚", accent:"#c4a882", bg:"#2c1810" },
  "Old Money":          { tags:["classic","tailored","refined","quiet luxury","preppy","clean","elevated","timeless"], season:["All"], emoji:"⛵", accent:"#8b7355", bg:"#f5f0e8" },
  "Grunge":             { tags:["flannel","ripped","band tee","combat boots","raw","distressed","90s","rebel"], season:["Fall","Winter"], emoji:"🎸", accent:"#8b2020", bg:"#1a0a0a" },
  "Soft Girl":          { tags:["pastel","cute","ribbons","pink","sweet","kawaii","feminine","dreamy","bows"], season:["Spring","Summer"], emoji:"🌸", accent:"#e87fa0", bg:"#fff0f5" },
  "Athleisure":         { tags:["sporty","leggings","gym","active","sneakers","fit","clean","performance","sleek"], season:["All"], emoji:"⚡", accent:"#e94560", bg:"#0f3460" },
  "Vintage":            { tags:["retro","thrifted","classic","timeless","nostalgic","antique","heritage","decades"], season:["Fall","Spring"], emoji:"🌹", accent:"#c8394a", bg:"#1a2a5e" },
  "Punk":               { tags:["studded","safety pins","combat","chains","leather","bold","anti-fashion","hardcore"], season:["Fall","Winter"], emoji:"🤘", accent:"#aa1515", bg:"#0a0a0a" },
  "Coquette":           { tags:["ballet","ribbon","satin","dainty","feminine","romantic","pink","flirty","lace"], season:["Spring","Summer"], emoji:"🎀", accent:"#d04870", bg:"#fff0f5" },
  "Minimalist":         { tags:["clean","simple","neutral","tonal","understated","basics","sleek","monochrome"], season:["All"], emoji:"⬜", accent:"#888", bg:"#f8f8f8" },
  "Coastal Grandmother":{ tags:["linen","breezy","nautical","relaxed","beach","effortless","classic","vacation"], season:["Summer","Spring"], emoji:"🌊", accent:"#3a7098", bg:"#c8dde8" },
};

const SEASON_ICON = { Spring:"🌸", Summer:"☀️", Fall:"🍂", Winter:"❄️", All:"✦" };
const ALL_STYLES  = Object.keys(STYLE_META);
const ALL_SEASONS = ["Spring","Summer","Fall","Winter"];

const PHOTO_SETS = {
  "Goth":               ["https://images.unsplash.com/photo-1518611540400-6b85a0704342?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800&q=90&fit=crop&crop=top"],
  "Cottagecore":        ["https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=800&q=90&fit=crop&crop=top"],
  "Streetwear":         ["https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1554568218-0f1715e72254?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1536766768598-e09213fdcf22?w=800&q=90&fit=crop&crop=top"],
  "Y2K":                ["https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=800&q=90&fit=crop&crop=top"],
  "Boho":               ["https://images.unsplash.com/photo-1512316609839-ce289d3eba0a?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1495385794356-15371f348229?w=800&q=90&fit=crop&crop=top"],
  "Dark Academia":      ["https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1520813792240-56fc4a3765a7?w=800&q=90&fit=crop&crop=top"],
  "Old Money":          ["https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1559582798-678dfc71ccd8?w=800&q=90&fit=crop&crop=top"],
  "Grunge":             ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1526510747491-58f928ec870f?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1541101767792-f9b2b1c4f127?w=800&q=90&fit=crop&crop=top"],
  "Soft Girl":          ["https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1488716820095-cbe80883c496?w=800&q=90&fit=crop&crop=top"],
  "Athleisure":         ["https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1576678927484-cc907957088c?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800&q=90&fit=crop&crop=top"],
  "Vintage":            ["https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=90&fit=crop&crop=top"],
  "Punk":               ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1526510747491-58f928ec870f?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800&q=90&fit=crop&crop=top"],
  "Coquette":           ["https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1488716820095-cbe80883c496?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&q=90&fit=crop&crop=top"],
  "Minimalist":         ["https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800&q=90&fit=crop&crop=top"],
  "Coastal Grandmother":["https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1495385794356-15371f348229?w=800&q=90&fit=crop&crop=top","https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=90&fit=crop&crop=top"],
};

const DESCS = {
  "Goth":["Black velvet corset + platform boots + silver chains","Sheer lace blouse + leather mini + fishnet tights","Floor-length duster + studded belt + choker"],
  "Cottagecore":["Floral prairie dress + wicker bag + Mary Janes","Puffed sleeve blouse + linen midi + straw hat","Embroidered peasant top + high-waist skirt"],
  "Streetwear":["Oversized graphic tee + cargo pants + AF1s","Cropped hoodie + wide-leg joggers + platforms","Biker shorts + oversized bomber + chunky Nikes"],
  "Y2K":["Low-rise flares + butterfly crop top + platforms","Lavender velour tracksuit + mini bag","Mini skirt + rhinestone belt + tube top"],
  "Boho":["Maxi floral skirt + crochet crop + fringe bag","Peasant blouse + wide-leg linen + woven sandals","Embroidered kimono over bralette + cutoffs"],
  "Dark Academia":["Plaid blazer + Oxford shirt + trousers + beret","Turtleneck + midi plaid skirt + knee socks","Corduroy trousers + cable knit + leather bag"],
  "Old Money":["Cashmere turtleneck + tailored trousers + loafers","Linen blazer + striped shirt + white pants","Silk midi in cream + structured bag + pearls"],
  "Grunge":["Flannel over band tee + ripped jeans + boots","Babydoll dress + leather jacket + chunky boots","Plaid pants + shrunken crop + platform Docs"],
  "Soft Girl":["Pastel gingham set + cloud bag + mary janes","Baby pink sweater + white mini + knee socks","Blush satin slip + white cardigan + bow headband"],
  "Athleisure":["Ribbed matching set + oversized jacket + sneakers","High-waist leggings + sports bra + zip hoodie","Flare leggings + cropped tank + crewneck"],
  "Vintage":["50s circle skirt + cinched blouse + kitten heels","70s wide-leg flares + peasant blouse + platforms","60s mod mini + block heels + go-go boots"],
  "Punk":["Plaid trousers + ripped band tee + leather jacket","Tartan skirt + studded belt + torn fishnets","Moto jacket with patches + graphic tee + boots"],
  "Coquette":["Ballet pink babydoll + lace socks + mary janes","Satin ribbon corset + tulle skirt + pearls","Baby blue babydoll + white tights + mary janes"],
  "Minimalist":["White button-down + black trousers + mules","Neutral ribbed set + sneakers + leather bag","Monochrome earth coord + structured tote"],
  "Coastal Grandmother":["Linen wide-legs + Breton shirt + woven bag","Relaxed blazer + white tee + beige trousers","Seafoam maxi linen dress + slide sandals"],
};

let _pid = 0;
const SEED_POSTS = [];
Object.entries(DESCS).forEach(([style, descs]) => {
  const meta = STYLE_META[style];
  const photos = PHOTO_SETS[style] || [];
  const seasons = meta.season.includes("All") ? ALL_SEASONS : meta.season;
  descs.forEach((desc, i) => {
    SEED_POSTS.push({ id:++_pid, style, season:seasons[i%seasons.length], desc, tags:meta.tags, photo:photos[i%photos.length], emoji:meta.emoji, accent:meta.accent, bg:meta.bg, username:"@fitcheck", isOwn:false });
  });
});

// ── AI STYLIST via Anthropic API ───────────────────────────────────────────────
async function getAIStylingAdvice(selfieBase64, outfits) {
  const outfitList = outfits.map((o, i) => `${i+1}. ${o.style} — ${o.desc}`).join("\n");
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{
        role: "user",
        content: [
          {
            type: "image",
            source: { type: "base64", media_type: "image/jpeg", data: selfieBase64 }
          },
          {
            type: "text",
            text: `You are a fun, hype fashion stylist AI. Look at this person's photo and analyze their vibe, body type, coloring, and personal style energy.

Then look at these outfits they liked:
${outfitList}

Give them:
1. A SHORT "Your Vibe" reading (2 sentences max, fun and affirming)
2. Your TOP 3 picks from their liked outfits and WHY each one would look incredible on them specifically — be specific about their features/coloring/body
3. One style tip personalized just for them

Be hyped, fun, like a best friend who knows fashion. Use emojis. Keep it under 250 words total. Format with clear sections.`
          }
        ]
      }]
    })
  });
  const data = await response.json();
  return data.content?.[0]?.text || "Couldn't load styling advice.";
}

// ── SWIPE CARD ─────────────────────────────────────────────────────────────────
function SwipeCard({ post, onSwipe, isTop, stackOffset }) {
  const cardRef = useRef(null);
  const startX = useRef(0);
  const currentX = useRef(0);
  const dragging = useRef(false);
  const m = STYLE_META[post.style];

  const onPointerDown = e => {
    if (!isTop) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragging.current = true;
    startX.current = e.clientX;
    currentX.current = e.clientX;
  };
  const onPointerMove = e => {
    if (!dragging.current || !isTop || !cardRef.current) return;
    currentX.current = e.clientX;
    const dx = e.clientX - startX.current;
    cardRef.current.style.transform = `translateX(${dx}px) rotate(${dx * 0.05}deg)`;
    cardRef.current.style.transition = "none";
    const l = cardRef.current.querySelector(".bl");
    const n = cardRef.current.querySelector(".bn");
    if (l) l.style.opacity = dx > 0 ? Math.min(dx / 60, 1) : 0;
    if (n) n.style.opacity = dx < 0 ? Math.min(-dx / 60, 1) : 0;
  };
  const onPointerUp = e => {
    if (!dragging.current) return;
    dragging.current = false;
    const dx = currentX.current - startX.current;
    if (Math.abs(dx) > 80) {
      onSwipe(dx > 0 ? "like" : "nope");
    } else if (cardRef.current) {
      cardRef.current.style.transition = "transform 0.35s cubic-bezier(.25,.46,.45,.94)";
      cardRef.current.style.transform = "";
      const l = cardRef.current.querySelector(".bl");
      const n = cardRef.current.querySelector(".bn");
      if (l) l.style.opacity = 0;
      if (n) n.style.opacity = 0;
    }
  };

  return (
    <div ref={cardRef}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove}
      onPointerUp={onPointerUp} onPointerCancel={onPointerUp}
      style={{ position:"absolute", inset:0, borderRadius:20, overflow:"hidden", background:m.bg,
        boxShadow: isTop ? "0 24px 80px rgba(0,0,0,0.6)" : "0 8px 30px rgba(0,0,0,0.3)",
        cursor: isTop ? "grab" : "default", userSelect:"none", touchAction:"none",
        transform: isTop ? "" : `scale(${0.94 - stackOffset*0.02}) translateY(${stackOffset*18}px)`,
        zIndex: isTop ? 10 : 5 - stackOffset,
        transition: isTop ? "box-shadow 0.2s" : "transform 0.3s ease",
      }}>
      <img src={post.photo} alt={post.desc} draggable={false} onError={e=>{e.target.style.display="none";}}
        style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover", objectPosition:"top center", pointerEvents:"none" }} />
      <div style={{ position:"absolute", inset:0, background:"linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, transparent 30%, transparent 45%, rgba(0,0,0,0.65) 72%, rgba(0,0,0,0.92) 100%)", pointerEvents:"none" }} />
      <div className="bl" style={{ position:"absolute", top:60, left:20, opacity:0, border:"5px solid #00e676", borderRadius:12, padding:"8px 20px", color:"#00e676", fontSize:28, fontWeight:900, fontFamily:"Impact,sans-serif", letterSpacing:3, transform:"rotate(-20deg)", pointerEvents:"none" }}>SLAY ✓</div>
      <div className="bn" style={{ position:"absolute", top:60, right:20, opacity:0, border:"5px solid #ff3060", borderRadius:12, padding:"8px 20px", color:"#ff3060", fontSize:28, fontWeight:900, fontFamily:"Impact,sans-serif", letterSpacing:3, transform:"rotate(20deg)", pointerEvents:"none" }}>NOPE ✕</div>
      <div style={{ position:"absolute", top:16, left:16, background:`${m.accent}ee`, backdropFilter:"blur(8px)", borderRadius:20, padding:"6px 14px", color:"#fff", fontSize:13, fontWeight:800, pointerEvents:"none" }}>{m.emoji} {post.style}</div>
      <div style={{ position:"absolute", top:16, right:16, background:"rgba(0,0,0,0.5)", backdropFilter:"blur(8px)", borderRadius:20, padding:"6px 12px", color:"rgba(255,255,255,0.9)", fontSize:12, pointerEvents:"none" }}>{SEASON_ICON[post.season]} {post.season}</div>
      <div style={{ position:"absolute", bottom:0, left:0, right:0, padding:"16px 18px 20px", pointerEvents:"none" }}>
        <p style={{ margin:"0 0 10px", fontSize:14, color:"rgba(255,255,255,0.92)", lineHeight:1.5, fontFamily:"Georgia,serif", textShadow:"0 1px 4px rgba(0,0,0,0.8)" }}>{post.desc}</p>
        <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
          {post.tags.slice(0,4).map(t => <span key={t} style={{ background:"rgba(255,255,255,0.15)", backdropFilter:"blur(4px)", borderRadius:12, padding:"3px 9px", color:"rgba(255,255,255,0.75)", fontSize:11 }}>#{t}</span>)}
        </div>
      </div>
    </div>
  );
}

// ── GRID CARD ──────────────────────────────────────────────────────────────────
function GridCard({ post, liked, onLike, onTryOn, selfie }) {
  const m = STYLE_META[post.style];
  return (
    <div style={{ borderRadius:14, overflow:"hidden", background:"#161616", border:"1px solid rgba(255,255,255,0.06)" }}>
      <div style={{ position:"relative", paddingTop:"130%", background:m.bg }}>
        <img src={post.photo} alt={post.desc} onError={e=>{e.target.style.display="none";}}
          style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover", objectPosition:"top" }} />
        <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 55%)", pointerEvents:"none" }} />
        <div style={{ position:"absolute", top:7, left:7, background:`${m.accent}dd`, borderRadius:14, padding:"3px 9px", color:"#fff", fontSize:9, fontWeight:800 }}>{m.emoji} {post.style}</div>
        <button onClick={()=>onLike(post)} style={{ position:"absolute", top:5, right:5, background:liked?"#ff3060":"rgba(0,0,0,0.55)", border:"none", borderRadius:"50%", width:28, height:28, color:"#fff", cursor:"pointer", fontSize:14, display:"flex", alignItems:"center", justifyContent:"center" }}>{liked?"♥":"♡"}</button>
        <div style={{ position:"absolute", bottom:6, left:8, right:8 }}>
          <div style={{ fontSize:9, color:"rgba(255,255,255,0.5)" }}>{SEASON_ICON[post.season]} {post.season}</div>
        </div>
      </div>
      <div style={{ padding:"8px 10px 10px" }}>
        <p style={{ margin:"0 0 8px", fontSize:10, color:"rgba(255,255,255,0.65)", lineHeight:1.4 }}>{post.desc}</p>
        {selfie && (
          <button onClick={()=>onTryOn(post)} style={{ width:"100%", background:`${m.accent}22`, border:`1px solid ${m.accent}55`, borderRadius:10, padding:"6px 0", color:m.accent, cursor:"pointer", fontSize:11, fontWeight:700 }}>
            ✦ Style Me in This
          </button>
        )}
      </div>
    </div>
  );
}

// ── AI STYLIST SCREEN ──────────────────────────────────────────────────────────
function AiStylistScreen({ selfie, selfieBase64, liked, onClose }) {
  const [advice, setAdvice]   = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone]       = useState(false);
  const [focusPost, setFocusPost] = useState(null);
  const [focusAdvice, setFocusAdvice] = useState("");
  const [focusLoading, setFocusLoading] = useState(false);

  const getFullReading = async () => {
    if (done || loading) return;
    setLoading(true);
    try {
      const result = await getAIStylingAdvice(selfieBase64, liked.slice(0, 8));
      setAdvice(result);
      setDone(true);
    } catch (e) {
      setAdvice("Couldn't connect to AI stylist. Make sure you're online!");
    }
    setLoading(false);
  };

  const getOutfitAdvice = async (post) => {
    setFocusPost(post);
    setFocusLoading(true);
    setFocusAdvice("");
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:600,
          messages:[{
            role:"user",
            content:[
              { type:"image", source:{ type:"base64", media_type:"image/jpeg", data:selfieBase64 }},
              { type:"text", text:`You are a fashion stylist. Look at this person's photo carefully — note their skin tone, hair, body shape, height (estimate), and overall vibe.

Now style them in this specific outfit: "${post.style} — ${post.desc}"

Give them:
🔥 Why this works FOR YOU specifically (mention their actual features)
👗 Exactly how to wear it — specific styling tips for their body/coloring
💄 Hair, makeup, accessories to complete the look
⚡ One way to make it even MORE them

Be specific, personal, hype, under 200 words. Use emojis.` }
            ]
          }]
        })
      });
      const data = await response.json();
      setFocusAdvice(data.content?.[0]?.text || "Couldn't load advice.");
    } catch(e) {
      setFocusAdvice("Couldn't connect. Try again!");
    }
    setFocusLoading(false);
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"#0a0a0a", zIndex:500, display:"flex", flexDirection:"column", maxWidth:480, margin:"0 auto" }}>
      {/* Header */}
      <div style={{ flexShrink:0, padding:"14px 18px 12px", borderBottom:"1px solid rgba(255,255,255,0.07)", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div style={{ fontFamily:"Georgia,serif", fontSize:20, fontWeight:900 }}>
          ✦ AI <span style={{color:"#ff3060"}}>Stylist</span>
        </div>
        <button onClick={onClose} style={{ background:"rgba(255,255,255,0.08)", border:"none", borderRadius:"50%", width:32, height:32, color:"rgba(255,255,255,0.6)", cursor:"pointer", fontSize:16, display:"flex", alignItems:"center", justifyContent:"center" }}>✕</button>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"16px 16px 30px" }}>

        {/* Selfie + liked strip */}
        <div style={{ display:"flex", gap:10, marginBottom:20, alignItems:"flex-start" }}>
          <div style={{ flexShrink:0 }}>
            <img src={selfie} alt="you" style={{ width:90, height:120, objectFit:"cover", objectPosition:"top", borderRadius:14, border:"2px solid #ff3060" }} />
            <div style={{ fontSize:9, color:"rgba(255,255,255,0.4)", textAlign:"center", marginTop:4 }}>Your photo</div>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:8 }}>Your liked looks ({liked.length})</div>
            <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
              {liked.slice(0,10).map(p => (
                <div key={p.id} onClick={()=>getOutfitAdvice(p)} style={{ flexShrink:0, width:54, height:72, borderRadius:10, overflow:"hidden", position:"relative", cursor:"pointer", border:`2px solid ${focusPost?.id===p.id?"#ff3060":"transparent"}`, transition:"border-color 0.2s" }}>
                  <img src={p.photo} alt="" onError={e=>{e.target.style.display="none";}} style={{ width:"100%", height:"100%", objectFit:"cover", objectPosition:"top" }} />
                  <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top,rgba(0,0,0,0.5) 0%,transparent 60%)" }} />
                  <div style={{ position:"absolute", bottom:2, left:0, right:0, textAlign:"center", fontSize:10 }}>{STYLE_META[p.style].emoji}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginTop:6 }}>Tap an outfit for personalized styling ↑</div>
          </div>
        </div>

        {/* Focus outfit advice */}
        {focusPost && (
          <div style={{ background:"#161616", borderRadius:16, padding:"14px 16px", marginBottom:16, border:`1px solid ${STYLE_META[focusPost.style].accent}44` }}>
            <div style={{ display:"flex", gap:10, marginBottom:10, alignItems:"center" }}>
              <img src={focusPost.photo} alt="" onError={e=>{e.target.style.display="none";}} style={{ width:48, height:62, objectFit:"cover", objectPosition:"top", borderRadius:8, flexShrink:0 }} />
              <div>
                <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>{STYLE_META[focusPost.style].emoji} {focusPost.style}</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.4, marginTop:2 }}>{focusPost.desc}</div>
              </div>
            </div>
            {focusLoading
              ? <div style={{ display:"flex", alignItems:"center", gap:10, color:"rgba(255,255,255,0.5)", fontSize:13, padding:"8px 0" }}>
                  <div style={{ width:16, height:16, border:"2px solid rgba(255,48,96,0.3)", borderTop:"2px solid #ff3060", borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
                  Styling you in this look…
                </div>
              : <p style={{ margin:0, fontSize:13, color:"rgba(255,255,255,0.85)", lineHeight:1.7, whiteSpace:"pre-wrap" }}>{focusAdvice}</p>
            }
          </div>
        )}

        {/* Full reading button */}
        {!done && !loading && liked.length > 0 && (
          <button onClick={getFullReading}
            style={{ width:"100%", padding:"14px", background:"linear-gradient(135deg,#ff3060,#ff6b8a)", border:"none", borderRadius:14, color:"#fff", fontSize:15, fontWeight:700, cursor:"pointer", boxShadow:"0 6px 20px rgba(255,48,96,0.4)", marginBottom:16 }}>
            ✦ Get My Full Style Reading
          </button>
        )}

        {loading && (
          <div style={{ textAlign:"center", padding:"20px 0", color:"rgba(255,255,255,0.5)" }}>
            <div style={{ fontSize:30, marginBottom:10, animation:"pulse 1.5s ease-in-out infinite" }}>✨</div>
            <div style={{ fontSize:14 }}>Analyzing your vibe + liked outfits…</div>
          </div>
        )}

        {/* Full advice */}
        {done && advice && (
          <div style={{ background:"#161616", borderRadius:16, padding:"16px", border:"1px solid rgba(255,48,96,0.2)" }}>
            <div style={{ fontSize:12, color:"#ff3060", fontWeight:700, letterSpacing:1, marginBottom:12 }}>✦ YOUR PERSONAL STYLE READING</div>
            <p style={{ margin:0, fontSize:14, color:"rgba(255,255,255,0.88)", lineHeight:1.8, whiteSpace:"pre-wrap", fontFamily:"Georgia,serif" }}>{advice}</p>
          </div>
        )}

        {liked.length === 0 && (
          <div style={{ textAlign:"center", padding:"30px 20px", color:"rgba(255,255,255,0.3)" }}>
            <div style={{fontSize:36}}>💔</div>
            <div style={{fontSize:14,marginTop:10}}>Like some outfits first, then come back for your reading!</div>
          </div>
        )}
      </div>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes pulse{0%,100%{opacity:0.5;transform:scale(1)}50%{opacity:1;transform:scale(1.2)}}`}</style>
    </div>
  );
}

// ── UPLOAD SELFIE MODAL ────────────────────────────────────────────────────────
function SelfieModal({ onClose, onSave }) {
  const [imgSrc, setImgSrc]     = useState(null);
  const [imgB64, setImgB64]     = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef(null);

  const handleFile = file => {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = e => {
      setImgSrc(e.target.result);
      // Extract base64 without prefix
      const b64 = e.target.result.split(",")[1];
      setImgB64(b64);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.88)", zIndex:800, display:"flex", alignItems:"flex-end", justifyContent:"center" }}
      onClick={e => { if(e.target===e.currentTarget) onClose(); }}>
      <div style={{ width:"100%", maxWidth:480, background:"#111", borderRadius:"24px 24px 0 0", padding:"24px 20px 36px" }}>
        <div style={{ width:40, height:4, background:"rgba(255,255,255,0.2)", borderRadius:2, margin:"0 auto 20px" }} />
        <div style={{ fontSize:20, fontWeight:800, fontFamily:"Georgia,serif", marginBottom:6 }}>
          Upload Your <span style={{color:"#ff3060"}}>Photo</span> 📸
        </div>
        <div style={{ fontSize:13, color:"rgba(255,255,255,0.4)", marginBottom:20 }}>
          Our AI stylist will use this to give you personalized outfit advice based on your looks
        </div>

        <div onClick={()=>fileRef.current?.click()}
          onDragOver={e=>{e.preventDefault();setDragOver(true);}}
          onDragLeave={()=>setDragOver(false)}
          onDrop={e=>{e.preventDefault();setDragOver(false);handleFile(e.dataTransfer.files[0]);}}
          style={{ width:"100%", aspectRatio:"3/4", maxHeight:320, borderRadius:16, border:`2px dashed ${dragOver?"#ff3060":imgSrc?"transparent":"rgba(255,255,255,0.2)"}`, background: imgSrc?"#000":"rgba(255,255,255,0.04)", cursor:"pointer", overflow:"hidden", position:"relative", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", marginBottom:16 }}>
          {imgSrc
            ? <img src={imgSrc} alt="" style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover", objectPosition:"top" }} />
            : <>
                <div style={{ fontSize:48, marginBottom:10 }}>🤳</div>
                <div style={{ color:"rgba(255,255,255,0.5)", fontSize:14, textAlign:"center" }}>Tap to upload your photo</div>
                <div style={{ color:"rgba(255,255,255,0.25)", fontSize:12, marginTop:4 }}>Full body or portrait works best</div>
              </>
          }
          {imgSrc && (
            <div style={{ position:"absolute", bottom:10, right:10, background:"rgba(0,0,0,0.65)", backdropFilter:"blur(6px)", borderRadius:20, padding:"5px 12px", color:"#fff", fontSize:11 }}>Change photo</div>
          )}
        </div>
        <input ref={fileRef} type="file" accept="image/*" style={{ display:"none" }} onChange={e=>handleFile(e.target.files[0])} />

        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onClose} style={{ flex:1, padding:"13px", background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:14, color:"rgba(255,255,255,0.6)", fontSize:14, cursor:"pointer" }}>Cancel</button>
          <button onClick={()=>{ if(imgSrc&&imgB64) { onSave(imgSrc, imgB64); onClose(); }}}
            style={{ flex:2, padding:"13px", background: imgSrc?"linear-gradient(135deg,#ff3060,#ff6b8a)":"rgba(255,255,255,0.08)", border:"none", borderRadius:14, color: imgSrc?"#fff":"rgba(255,255,255,0.3)", fontSize:14, fontWeight:700, cursor: imgSrc?"pointer":"default", boxShadow: imgSrc?"0 6px 20px rgba(255,48,96,0.4)":"none" }}>
            {imgSrc ? "Save & Style Me ✦" : "Choose a photo first"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN ───────────────────────────────────────────────────────────────────────
export default function FitCheck() {
  const [userPosts, setUserPosts]     = useState([]);
  const [liked, setLiked]             = useState([]);
  const [idx, setIdx]                 = useState(0);
  const [flyOut, setFlyOut]           = useState(null);
  const [tab, setTab]                 = useState("discover");
  const [selfie, setSelfie]           = useState(null);       // data URL for display
  const [selfieB64, setSelfieB64]     = useState(null);       // raw base64 for API
  const [showSelfie, setShowSelfie]   = useState(false);
  const [showStylist, setShowStylist] = useState(false);
  const [showUpload, setShowUpload]   = useState(false);
  const [actSeason, setActSeason]     = useState("All");
  const [actStyle, setActStyle]       = useState("All");
  const [focusTryOn, setFocusTryOn]   = useState(null);

  const deckRef = useRef([...SEED_POSTS].sort(() => Math.random() - 0.5));
  const deck    = deckRef.current;
  const likedIds = new Set(liked.map(p => p.id));

  const handleSwipe = useCallback(dir => {
    const post = deck[idx % deck.length];
    setFlyOut({ dir, post });
    if (dir === "like" && !likedIds.has(post.id)) setLiked(prev => [...prev, post]);
    setTimeout(() => { setFlyOut(null); setIdx(i => i + 1); }, 420);
  }, [idx, likedIds, deck]);

  const handleLike = useCallback(post => setLiked(prev => prev.find(p=>p.id===post.id) ? prev.filter(p=>p.id!==post.id) : [...prev, post]), []);

  const handleUpload = useCallback(post => {
    setUserPosts(prev => [post, ...prev]);
    deckRef.current = [post, ...deckRef.current];
    setIdx(0);
  }, []);

  const curr  = deck[idx % deck.length];
  const next1 = deck[(idx+1) % deck.length];
  const next2 = deck[(idx+2) % deck.length];

  const likedStyles   = ["All", ...[...new Set(liked.map(p=>p.style))]];
  const likedFiltered = liked.filter(p => (actSeason==="All"||p.season===actSeason) && (actStyle==="All"||p.style===actStyle));

  return (
    <div style={{ width:"100%", maxWidth:480, margin:"0 auto", height:"100vh", background:"#080808", color:"#fff", fontFamily:"system-ui,sans-serif", display:"flex", flexDirection:"column", overflow:"hidden" }}>

      {/* ── HEADER ── */}
      <div style={{ flexShrink:0, padding:"12px 16px 10px", borderBottom:"1px solid rgba(255,255,255,0.07)", background:"rgba(8,8,8,0.96)", backdropFilter:"blur(14px)", zIndex:200, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div style={{ fontFamily:"Georgia,serif", fontSize:24, fontWeight:900, letterSpacing:-1 }}>
          Fit<span style={{color:"#ff3060"}}>Check</span>
        </div>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          {/* AI Stylist button — glows if selfie uploaded */}
          <button onClick={()=>{ if(selfie) setShowStylist(true); else setShowSelfie(true); }}
            style={{ background: selfie ? "linear-gradient(135deg,#7b2ff7,#ff3060)" : "rgba(255,255,255,0.07)", border: selfie ? "none" : "1px solid rgba(255,255,255,0.12)", borderRadius:20, padding:"7px 12px", color:"#fff", cursor:"pointer", fontSize:12, fontWeight:700, display:"flex", alignItems:"center", gap:5, boxShadow: selfie ? "0 4px 16px rgba(123,47,247,0.5)" : "none", transition:"all 0.2s" }}>
            {selfie
              ? <><img src={selfie} alt="" style={{ width:20, height:20, borderRadius:"50%", objectFit:"cover" }} /> AI Stylist ✦</>
              : <>🤳 Style Me</>
            }
          </button>
          <button onClick={()=>setShowUpload(true)}
            style={{ background:"linear-gradient(135deg,#ff3060,#ff6b8a)", border:"none", borderRadius:20, padding:"7px 14px", color:"#fff", cursor:"pointer", fontSize:13, fontWeight:700, boxShadow:"0 4px 14px rgba(255,48,96,0.4)", display:"flex", alignItems:"center", gap:4 }}>
            + Post
          </button>
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div style={{ flex:1, overflow:"hidden", position:"relative" }}>

        {/* DISCOVER */}
        {tab==="discover" && (
          <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column" }}>
            <div style={{ flex:1, position:"relative", margin:"12px 14px 0" }}>
              {next2 && <SwipeCard post={next2} onSwipe={()=>{}} isTop={false} stackOffset={2} />}
              {next1 && <SwipeCard post={next1} onSwipe={()=>{}} isTop={false} stackOffset={1} />}
              {flyOut && (
                <div style={{ position:"absolute", inset:0, borderRadius:20, overflow:"hidden", background:STYLE_META[flyOut.post.style].bg,
                  transform: flyOut.dir==="like" ? "translateX(150%) rotate(30deg)" : "translateX(-150%) rotate(-30deg)",
                  transition:"transform 0.4s cubic-bezier(.25,.46,.45,.94)", zIndex:20, pointerEvents:"none" }}>
                  <img src={flyOut.post.photo} draggable={false} style={{ width:"100%", height:"100%", objectFit:"cover", objectPosition:"top" }} />
                </div>
              )}
              {!flyOut && curr && <SwipeCard post={curr} onSwipe={handleSwipe} isTop={true} stackOffset={0} />}
            </div>
            <div style={{ flexShrink:0, display:"flex", justifyContent:"center", alignItems:"center", gap:18, padding:"14px 0 10px" }}>
              <button onClick={()=>handleSwipe("nope")} style={{ width:58, height:58, borderRadius:"50%", background:"rgba(255,60,60,0.1)", border:"2px solid rgba(255,60,60,0.35)", color:"#ff4444", fontSize:22, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}
                onMouseEnter={e=>{e.currentTarget.style.background="rgba(255,60,60,0.25)";e.currentTarget.style.transform="scale(1.08)";}}
                onMouseLeave={e=>{e.currentTarget.style.background="rgba(255,60,60,0.1)";e.currentTarget.style.transform="scale(1)";}}>✕</button>
              <button onClick={()=>handleSwipe("like")} style={{ width:72, height:72, borderRadius:"50%", background:"linear-gradient(135deg,#ff3060,#ff6b8a)", border:"none", color:"#fff", fontSize:30, cursor:"pointer", boxShadow:"0 8px 28px rgba(255,48,96,0.55)", display:"flex", alignItems:"center", justifyContent:"center" }}
                onMouseEnter={e=>{e.currentTarget.style.transform="scale(1.1)";e.currentTarget.style.boxShadow="0 12px 36px rgba(255,48,96,0.7)";}}
                onMouseLeave={e=>{e.currentTarget.style.transform="scale(1)";e.currentTarget.style.boxShadow="0 8px 28px rgba(255,48,96,0.55)";}}>♥</button>
              <button onClick={()=>setIdx(i=>i+1)} style={{ width:58, height:58, borderRadius:"50%", background:"rgba(255,255,255,0.05)", border:"2px solid rgba(255,255,255,0.12)", color:"rgba(255,255,255,0.4)", fontSize:22, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}
                onMouseEnter={e=>{e.currentTarget.style.background="rgba(255,255,255,0.12)";e.currentTarget.style.transform="scale(1.08)";}}
                onMouseLeave={e=>{e.currentTarget.style.background="rgba(255,255,255,0.05)";e.currentTarget.style.transform="scale(1)";}}>↷</button>
            </div>
            <div style={{ textAlign:"center", fontSize:10, color:"rgba(255,255,255,0.18)", paddingBottom:8 }}>drag left or right · ♥ like · ↷ skip</div>
          </div>
        )}

        {/* LIKED */}
        {tab==="liked" && (
          <div style={{ position:"absolute", inset:0, overflowY:"auto" }}>
            {/* AI Stylist CTA if selfie not set */}
            {!selfie && liked.length > 0 && (
              <div onClick={()=>setShowSelfie(true)} style={{ margin:"12px 14px 0", background:"linear-gradient(135deg,#7b2ff722,#ff306022)", border:"1px solid rgba(255,48,96,0.3)", borderRadius:14, padding:"12px 16px", display:"flex", alignItems:"center", gap:12, cursor:"pointer" }}>
                <div style={{ fontSize:26 }}>🤳</div>
                <div>
                  <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>Upload your photo</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)" }}>Get AI styling advice for your liked outfits</div>
                </div>
                <div style={{ marginLeft:"auto", color:"#ff3060", fontSize:18 }}>→</div>
              </div>
            )}
            {selfie && liked.length > 0 && (
              <div onClick={()=>setShowStylist(true)} style={{ margin:"12px 14px 0", background:"linear-gradient(135deg,#7b2ff733,#ff306033)", border:"1px solid rgba(255,48,96,0.4)", borderRadius:14, padding:"12px 16px", display:"flex", alignItems:"center", gap:12, cursor:"pointer" }}>
                <img src={selfie} alt="" style={{ width:40, height:40, borderRadius:"50%", objectFit:"cover", border:"2px solid #ff3060" }} />
                <div>
                  <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>✦ Open AI Stylist</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)" }}>See which looks work best for you</div>
                </div>
                <div style={{ marginLeft:"auto", color:"#ff3060", fontSize:18 }}>→</div>
              </div>
            )}

            <div style={{ padding:"12px 14px 0", borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
              <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:10 }}>
                {["All","Spring","Summer","Fall","Winter"].map(s=>(
                  <button key={s} onClick={()=>setActSeason(s)} style={{ flexShrink:0, background:actSeason===s?"#ff3060":"rgba(255,255,255,0.07)", border:`1px solid ${actSeason===s?"#ff3060":"rgba(255,255,255,0.1)"}`, borderRadius:20, padding:"7px 14px", color:actSeason===s?"#fff":"rgba(255,255,255,0.55)", cursor:"pointer", fontSize:12, fontWeight:actSeason===s?700:400, transition:"all 0.2s" }}>
                    {SEASON_ICON[s]} {s}
                  </button>
                ))}
              </div>
              {liked.length > 0 && (
                <div style={{ display:"flex", gap:7, overflowX:"auto", paddingBottom:12 }}>
                  {likedStyles.map(s => {
                    const m = s==="All" ? null : STYLE_META[s];
                    return <button key={s} onClick={()=>setActStyle(s)} style={{ flexShrink:0, background:actStyle===s?(m?`${m.accent}33`:"rgba(255,255,255,0.15)"):"rgba(255,255,255,0.05)", border:`1px solid ${actStyle===s?(m?m.accent:"rgba(255,255,255,0.3)"):"rgba(255,255,255,0.08)"}`, borderRadius:20, padding:"5px 12px", color:actStyle===s?"#fff":"rgba(255,255,255,0.45)", cursor:"pointer", fontSize:11, transition:"all 0.2s" }}>{m?`${m.emoji} `:"✦ "}{s}</button>;
                  })}
                </div>
              )}
            </div>

            {liked.length === 0
              ? <div style={{ textAlign:"center", padding:"60px 20px", color:"rgba(255,255,255,0.3)" }}><div style={{fontSize:52}}>💔</div><div style={{fontSize:18,marginTop:14,fontFamily:"Georgia,serif"}}>No liked outfits yet</div><div style={{fontSize:13,marginTop:8}}>Swipe right or tap ♥ to save looks</div></div>
              : likedFiltered.length === 0
              ? <div style={{ textAlign:"center", padding:"40px 20px", color:"rgba(255,255,255,0.3)" }}><div style={{fontSize:36}}>🔍</div><div style={{fontSize:15,marginTop:12}}>No saved looks match this filter</div></div>
              : <div style={{ padding:"12px 12px 80px" }}>
                  <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", letterSpacing:1.5, marginBottom:12 }}>{likedFiltered.length} SAVED{actSeason!=="All"?` · ${actSeason.toUpperCase()}`:""}{ actStyle!=="All"?` · ${actStyle.toUpperCase()}`:""}</div>
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                    {likedFiltered.map(post => (
                      <GridCard key={post.id} post={post} liked={likedIds.has(post.id)} onLike={handleLike}
                        onTryOn={p=>{ setFocusTryOn(p); setShowStylist(true); }}
                        selfie={selfie} />
                    ))}
                  </div>
                </div>
            }
          </div>
        )}
      </div>

      {/* ── BOTTOM NAV ── */}
      <div style={{ flexShrink:0, borderTop:"1px solid rgba(255,255,255,0.08)", background:"rgba(8,8,8,0.97)", backdropFilter:"blur(16px)", display:"flex", padding:"8px 0 12px", zIndex:300 }}>
        {[
          { id:"discover", icon:"✦", label:"Discover" },
          { id:"liked",    icon:"♥", label: liked.length>0 ? `Liked (${liked.length})` : "Liked" },
        ].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{ flex:1, background:"none", border:"none", color:tab===t.id?"#ff3060":"rgba(255,255,255,0.3)", cursor:"pointer", padding:"4px 0", display:"flex", flexDirection:"column", alignItems:"center", gap:2, transition:"color 0.2s" }}>
            <span style={{fontSize:20}}>{t.icon}</span>
            <span style={{fontSize:10,letterSpacing:0.3,fontWeight:tab===t.id?700:400}}>{t.label}</span>
          </button>
        ))}
      </div>

      {/* ── MODALS ── */}
      {showSelfie && (
        <SelfieModal
          onClose={()=>setShowSelfie(false)}
          onSave={(src, b64)=>{ setSelfie(src); setSelfieB64(b64); setTimeout(()=>setShowStylist(true), 300); }}
        />
      )}

      {showStylist && selfie && (
        <AiStylistScreen
          selfie={selfie}
          selfieBase64={selfieB64}
          liked={liked}
          onClose={()=>{ setShowStylist(false); setFocusTryOn(null); }}
        />
      )}

      {/* Upload post modal */}
      {showUpload && (
        <UploadModal onClose={()=>setShowUpload(false)} onUpload={handleUpload} />
      )}

      <style>{`* { box-sizing:border-box; -webkit-tap-highlight-color:transparent; } ::-webkit-scrollbar { display:none; }`}</style>
    </div>
  );
}

// ── UPLOAD POST MODAL (kept from before) ──────────────────────────────────────
function UploadModal({ onClose, onUpload }) {
  const [imgSrc, setImgSrc]   = useState(null);
  const [style, setStyle]     = useState("");
  const [season, setSeason]   = useState("Spring");
  const [desc, setDesc]       = useState("");
  const [dragOver, setDragOver]=useState(false);
  const fileRef = useRef(null);

  const handleFile = file => {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = e => setImgSrc(e.target.result);
    reader.readAsDataURL(file);
  };
  const canSubmit = imgSrc && style && desc.trim();
  const submit = () => {
    if (!canSubmit) return;
    const m = STYLE_META[style];
    onUpload({ id:Date.now(), style, season, desc:desc.trim(), tags:m.tags, photo:imgSrc, emoji:m.emoji, accent:m.accent, bg:m.bg, username:"@you", isOwn:true });
    onClose();
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", zIndex:700, display:"flex", alignItems:"flex-end", justifyContent:"center" }}
      onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div style={{ width:"100%", maxWidth:480, background:"#111", borderRadius:"24px 24px 0 0", padding:"24px 20px 36px", maxHeight:"92vh", overflowY:"auto" }}>
        <div style={{ width:40, height:4, background:"rgba(255,255,255,0.2)", borderRadius:2, margin:"0 auto 20px" }} />
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
          <div style={{ fontSize:20, fontWeight:800, fontFamily:"Georgia,serif" }}>Post Your <span style={{color:"#ff3060"}}>Fit</span> 📸</div>
          <button onClick={onClose} style={{ background:"rgba(255,255,255,0.08)", border:"none", borderRadius:"50%", width:32, height:32, color:"rgba(255,255,255,0.6)", cursor:"pointer", fontSize:16, display:"flex", alignItems:"center", justifyContent:"center" }}>✕</button>
        </div>
        <div onClick={()=>fileRef.current?.click()} onDragOver={e=>{e.preventDefault();setDragOver(true);}} onDragLeave={()=>setDragOver(false)}
          onDrop={e=>{e.preventDefault();setDragOver(false);handleFile(e.dataTransfer.files[0]);}}
          style={{ width:"100%", aspectRatio:"3/4", maxHeight:260, borderRadius:16, border:`2px dashed ${dragOver?"#ff3060":imgSrc?"transparent":"rgba(255,255,255,0.2)"}`, background:imgSrc?"#000":"rgba(255,255,255,0.04)", cursor:"pointer", overflow:"hidden", position:"relative", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", marginBottom:16 }}>
          {imgSrc ? <img src={imgSrc} alt="" style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover", objectPosition:"top" }} /> : <><div style={{fontSize:36,marginBottom:8}}>📷</div><div style={{color:"rgba(255,255,255,0.5)",fontSize:13}}>Tap to upload</div></>}
          {imgSrc && <div style={{ position:"absolute", bottom:8, right:8, background:"rgba(0,0,0,0.65)", backdropFilter:"blur(6px)", borderRadius:20, padding:"4px 10px", color:"#fff", fontSize:10 }}>Change</div>}
        </div>
        <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])} />

        <div style={{ marginBottom:12 }}>
          <label style={{ fontSize:10, color:"rgba(255,255,255,0.4)", letterSpacing:1, display:"block", marginBottom:7 }}>STYLE *</label>
          <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
            {ALL_STYLES.map(s => { const m=STYLE_META[s]; return <button key={s} onClick={()=>setStyle(s)} style={{ background:style===s?`${m.accent}44`:"rgba(255,255,255,0.05)", border:`1px solid ${style===s?m.accent:"rgba(255,255,255,0.1)"}`, borderRadius:20, padding:"5px 11px", color:style===s?"#fff":"rgba(255,255,255,0.5)", cursor:"pointer", fontSize:11, transition:"all 0.15s" }}>{m.emoji} {s}</button>; })}
          </div>
        </div>
        <div style={{ marginBottom:12 }}>
          <label style={{ fontSize:10, color:"rgba(255,255,255,0.4)", letterSpacing:1, display:"block", marginBottom:7 }}>SEASON</label>
          <div style={{ display:"flex", gap:7 }}>
            {ALL_SEASONS.map(s => <button key={s} onClick={()=>setSeason(s)} style={{ flex:1, background:season===s?"#ff3060":"rgba(255,255,255,0.07)", border:`1px solid ${season===s?"#ff3060":"rgba(255,255,255,0.1)"}`, borderRadius:12, padding:"7px 0", color:season===s?"#fff":"rgba(255,255,255,0.5)", cursor:"pointer", fontSize:12, fontWeight:season===s?700:400 }}>{SEASON_ICON[s]} {s}</button>)}
          </div>
        </div>
        <div style={{ marginBottom:18 }}>
          <label style={{ fontSize:10, color:"rgba(255,255,255,0.4)", letterSpacing:1, display:"block", marginBottom:7 }}>OUTFIT DESCRIPTION *</label>
          <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="e.g. Black midi dress + platform boots + chains" rows={2}
            style={{ width:"100%", background:"#1c1c1c", border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"10px 14px", color:"#fff", fontSize:13, outline:"none", resize:"none", boxSizing:"border-box", fontFamily:"inherit" }} />
        </div>
        <button onClick={submit} style={{ width:"100%", padding:"13px", background:canSubmit?"linear-gradient(135deg,#ff3060,#ff6b8a)":"rgba(255,255,255,0.1)", border:"none", borderRadius:14, color:canSubmit?"#fff":"rgba(255,255,255,0.3)", fontSize:14, fontWeight:700, cursor:canSubmit?"pointer":"default", boxShadow:canSubmit?"0 6px 20px rgba(255,48,96,0.4)":"none" }}>
          {canSubmit ? "✦ Post to FitCheck" : "Fill in all fields to post"}
        </button>
      </div>
    </div>
  );
}
